class B implements Runnable {
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("Thread - " + i);
            try {
                Thread.sleep(500);
            } catch (InterruptedException e) {
                System.out.println(e.getMessage());
            }
        }
    }
}

class Main {
    public static void main(String[] args) {
        B obj = new B();
        Thread t = new Thread(obj);
        t.start();
    }
}
