# Java College Practicals (Practical 03 onward)

These files are typed from the uploaded handwritten Java practical notebook and formatted for readability.

## Notes
- Each `.java` file is independent. The simple class names (`A`, `B`, `C`, `Gen`, and `Main`) follow common college practical style.
- Because several files use the class name `Main`, compile/run one file at a time from its own folder or rename the entry class if combining files into one folder and compiling together.
- File-handling examples expect the sample input files (`SYIT.txt`) to exist in the working directory.
- Practical numbering for a few pages was unclear in the notebook; filenames use the topic sequence for organization.
